/*
 *  Canvas Lab;
 *  John Park;
 *  Dr. Gabor's Web Application Development class
 *  11/12/14
*/

function loadGrid(xMin, xMax, xScl, yMin, yMax, yScl)  {
    //for now, assume axis1 and axis2 equal "x" and "y", arguments are in place for potential 3D
    
    
    var intervalX = canvas.width / ((xMax - xMin) / xScl);
    var intervalY = canvas.height / ((yMax - yMin) / yScl);
    //code below graphs xy plane

    //draw vertical lines, y = constant
    for(x = intervalX; x < (canvas.width); x += intervalX) {
        cdraw.moveTo(x, 0);
        cdraw.lineTo(x, canvas.height);
        cdraw.stroke();
    }
    
    //draw horizontal lines, x = constant
    for(y = intervalY; y < (canvas.height - intervalY); y += intervalY) {
        cdraw.moveTo(0, y);
        cdraw.lineTo(canvas.width, y);
        cdraw.stroke();
    }
}

/////////////////////////////////////////




/////////////////////////////////////////


function startProgram() {
    canvas = document.getElementById("canvas_graph");
    cdraw = canvas.getContext("2d");
    
    defaults = {"xMin":-30, "xMax":30, "xScl":3, "yMin":-30, "yMax":30, "yScl":3};
    
//    cdraw.fillRect(0,0,100,200);
    loadGrid(defaults.xMin, defaults.xMax, defaults.xScl, defaults.yMin, defaults.yMax, defaults.yScl);
}